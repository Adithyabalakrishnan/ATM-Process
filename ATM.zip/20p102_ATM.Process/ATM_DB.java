package ATMassign;
public class ATM_DB {
    private int balanceAmount;
    private  int deposingAmount;
    private int withdrawAmount;

    public ATM_DB () {
    }

    public ATM_DB (int balanceAmount, int deposingAmount, int withdrawAmount) {
        this.balanceAmount = balanceAmount;
        this.deposingAmount = deposingAmount;
        this.withdrawAmount = withdrawAmount;
    }

    public int getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(int balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public int getDeposingAmount() {
        return deposingAmount;
    }

    public void setDeposingAmount(int deposingAmount) {
        this.deposingAmount = deposingAmount;
    }

    public int getWithdrawAmount() {
        return withdrawAmount;
    }

    public void setWithdrawAmount(int withdrawAmount) {
        this.withdrawAmount = withdrawAmount;
    }
}
