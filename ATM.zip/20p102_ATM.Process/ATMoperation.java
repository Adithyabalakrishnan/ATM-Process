package ATMassign;
public class ATMoperation {
    public static void updateDenomination(int amount, int denomination, denom_op denom_op){
        if(amount==2000){
                denom_op.setTwoThousand(denom_op.getTwoThousand()+denomination);
        }
        else if(amount==500){
        	denom_op.setFiveHundred(denom_op.getFiveHundred()+denomination);
        }
        else if(amount==100){
        	denom_op.setOneHundred(denom_op.getOneHundred()+denomination);
        }
    }

    public static int reduceDenomination(int amount, int denomination, denom_op denom_op){
        int flag1=0, flag2=0;
        if(amount==2000){
            if(denom_op.getTwoThousand()>0){
            	denom_op.setTwoThousand(denom_op.getTwoThousand()-denomination);
                return 1;
            }
            else if(denom_op.getFiveHundred()>0){
                flag1=1;
                denom_op.setFiveHundred(denom_op.getFiveHundred()-denomination);
            }
            else if(denom_op.getOneHundred()>0){
                flag2=1;
                denom_op.setOneHundred(denom_op.getOneHundred()-denomination);
            }
        }
        else if(amount==500){
            if(denom_op.getFiveHundred()>0){
                if(flag1==0){
                	denom_op.setFiveHundred(denom_op.getFiveHundred()-denomination);
                    return 1;
                }
            }
            else if(denom_op.getOneHundred()>0)
                if(flag2==0)
                	denom_op.setOneHundred(denom_op.getOneHundred()-denomination);
        }
        else if(amount==100){
            if(denom_op.getOneHundred()>0){
                if(flag2==0){
                	denom_op.setOneHundred(denom_op.getOneHundred()-denomination);
                return 1;}
            }
        }
        return -1;
    }

    public static void updateDepositingAmount(ATM_DB atmDatabase, denom_op denom_op){
        int depositingAmount=denom_op.getTwoThousand()*2000+denom_op.getFiveHundred()*500+denom_op.getOneHundred()*100;
        atmDatabase.setDeposingAmount(depositingAmount);
        atmDatabase.setBalanceAmount(atmDatabase.getDeposingAmount());
    }

    public static void updateWithdraw(ATM_DB atmDatabase, int withdrawAmount){
        atmDatabase.setWithdrawAmount(withdrawAmount);
        atmDatabase.setBalanceAmount(atmDatabase.getBalanceAmount()-withdrawAmount);
    }

    public static int[] dispensingDenomination(int[] notes, int withdrawAmount){
        int[] noteCounter=new int[notes.length];
        for(int i=0;i<notes.length;i++){
            if(withdrawAmount>=notes[i]){
                noteCounter[i]=withdrawAmount/notes[i];
                withdrawAmount=withdrawAmount-noteCounter[i]*notes[i];
            }
        }
        return noteCounter;
    }

}









